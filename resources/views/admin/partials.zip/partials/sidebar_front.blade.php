{{--*/ $breadcum = ucwords(str_replace(array("_","/"),' ',str_replace(url(''),'',url()->current()))) /*--}}
 <div class="page-title-3" id="page-title" style="margin-top: 167px;">
            <div class="page-title-inner who_wr_img light">
                <!-- .container start -->
                <div class="container">
                    <!-- .row start -->
                    <div class="row">
                        <div class="col-md-12">
                            <!-- .title-container start -->
                            <section class="title-container clearfix">
                                <div class="pt-title">
								<?php $position = strpos($breadcum,"Search");
								$detail = strpos($breadcum,"Article Details");
								$details = strpos($breadcum,"Blog Details");
								$keyword = DB::table('searchkeyword')
								->select('searchkeyword.keyword')
								->where('searchkeyword.id', '=',@Session::get('key'))
								->get();
								if($position==1)
								{
									if (Auth::check())
									{
										$user_id=Auth::user()->id; 
										$login_status=1;
									}
									else
									{
										$user_id =Session::getId();
										$login_status=0;											
									}
									//$ip = $_SERVER['REMOTE_ADDR'];
									$ip = "103.225.42.90";
									$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));
									$location=  $details->city.', '.$details->region;
									
									DB::table('numa_search_history')->insert(
									['location'=>$location,'login_status'=>$login_status,'status'=>'Active','user_id'=>$user_id,'ip_address'=>$_SERVER['REMOTE_ADDR'],'seach_keyword' =>$keyword[0]->keyword,
									'created_date'=>date('Y-m-d H:i:s')]
									);
									echo '<h1>Your symptoms point towards <strong>"'.$keyword[0]->keyword.'"</strong></h1>';
								}
								else if($detail==1)
								{
									$details = DB::table('diseasesarticle')
									->select('article_title')
									->where('diseasesarticle.status', '=','Active')
									->where('id', '=',@Request::segment(2))
									->get();
									if(empty($detail))
									{
										return Redirect::to('search_result')->send();
											
									}
									echo '<h1>Article Detail <strong>"'.$details[0]->article_title.'"</strong></h1>';
									$breadcum = $details[0]->article_title;
								}
								else if($details==1)
								{
								$details = DB::table('blog')
									->select('blog_name')
									->where('blog.status', '=','Active')
									->where('id', '=',@Request::segment(2))
									->get();
									if(empty($details))
									{
										return Redirect::to('search_result')->send();
											
									}
									echo '<h1>Article Detail <strong>"'.$details[0]->blog_name.'"</strong></h1>';
									$breadcum = $details[0]->blog_name;
								}
								else {?>
								<h1>{{ $breadcum  }}</h1>
								<?php } ?>
								
                                </div><!-- .pt-title end -->

                                <!-- .pt-info end -->
                            </section><!-- .title-container end -->
                        </div><!-- .col-md-12 end -->
                    </div><!-- .row end -->                
                </div><!-- .container end -->
            </div><!-- .page-title-inner end -->

            <!--.breadcrumbs-container start -->
            <div class="breadcrumbs-container theme-color">
                <!-- .CONTAINER START -->
                <div class="container">
                    <!-- .row start -->
                    <div class="row">
                        <!-- .col-md-12 start -->
                        <div class="col-md-12">
                            <ul class="breadcrumb">
                                <li>You are here:</li>
                                <li><a href="{{url('')}}">Home</a></li>
                                <li><span class="active">{{ $breadcum }}</span></li>
                            </ul><!-- .breadcrumb end -->
                        </div><!-- .col-md-12 end -->
                    </div><!-- .row end -->
                </div><!-- .container end -->
            </div><!-- .breadcrumb-container end -->
        </div>   