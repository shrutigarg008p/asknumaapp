<footer id="site-footer">
	<section>©2016 All Rights Reserved by AskNuma.com </section>
</footer>
<nav id="menu" data-search="close">
  <ul>
 
	@foreach($menus as $menu)
                @if($menu->menu_type != 2 && is_null($menu->parent_id))
                    @if(Auth::user()->role->canAccessMenu($menu))
                        <li @if(isset(explode('/',Request::path())[1]) && explode('/',Request::path())[1] == strtolower($menu->name)) class="active" @endif>
                            <a href="{{ route(config('quickadmin.route').'.'.strtolower($menu->name).'.index') }}">
                                <i class="icon fa {{ $menu->icon }}"></i>
                                <span class="title">{{ $menu->title }}</span>
                            </a>
                        </li>
                    @endif
                @else
                    @if(Auth::user()->role->canAccessMenu($menu) && !is_null($menu->children()->first()) && is_null($menu->parent_id))
                        <li>
                            <a href="#">
                                <i class="fa {{ $menu->icon }}"></i>
                                <span class="title">{{ $menu->title }}</span>
                                <span class="fa arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                @foreach($menu['children'] as $child)
                                    @if(Auth::user()->role->canAccessMenu($child))
                                        <li
                                                @if(isset(explode('/',Request::path())[1]) && explode('/',Request::path())[1] == strtolower($child->name)) class="active active-sub" @endif>
                                            <a href="{{ route(config('quickadmin.route').'.'.strtolower($child->name).'.index') }}">
                                                <i class="fa {{ $child->icon }}"></i>
                                                <span class="title">
                                                    {{ $child->title  }}
                                                </span>
                                            </a>
                                        </li>
                                    @endif
                                @endforeach
                            </ul>
                        </li>
                    @endif
                @endif
            @endforeach
             <li><a href="{{ url('') }}"><i class="icon  fa  fa-home"></i> Search Keyword </a></li>
	<li><a href="{{ url('admin/bookmark') }}"><i class="icon  fa  fa-rocket"></i> Pinned Media </a></li>
	<li><a href="{{ url('our_blog') }}"><i class="icon  fa  fa-rss"></i> Blog </a></li>
    <li><a href="{{ url('admin/setting') }}"><i class="icon  fa fa-gears"></i> My Profile  </a></li>
    <!--li><a href="#"><i class="icon  fa fa-rocket"></i> Print Media</a></li>
    <li><a href="#"><i class="icon  fa fa-search"></i> Search History</a></li-->
    
    
    <!--li> <span><i class="icon  fa  fa-rocket"></i> Blank Page</span>
      <ul>
        <li><a href="{{ url('admin/setting') }}"><i class="icon  fa fa-th"></i> Setting Two </a></li>
      </ul>
    </li-->
    
  </ul>
</nav>
		
		
		
		
		
		
