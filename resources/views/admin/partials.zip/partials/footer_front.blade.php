<div id="copyright-container"> 
  <!-- .container start -->
  <div class="container"> 
    
    <!-- .col-md-6 start -->
    <div class="col-md-8 ">
      <ul class="breadcrumb footer-breadcrumb" style=" float:left; width:100%;">
        <li><a href="{{ url('/term_condition')}}">Terms of Service</a></li>
        <li><a href="{{ url('/privacy_policy')}}">Privacy Policy</a></li>
      </ul>
      <p style="display:block"> &copy; 2016 All Rights Reserved by AskNuma.com</p>
    </div>
    <!-- .ocl-md-6 end -->
    
    <div class="col-md-4 widget widget_newsletterwidget ">
      <div class="title" >
        <h4>Newsletter Subscribes</h4>
      </div>
      <div class="newsletter">
        <input name="newsletter" id="news_letter_email" class="email" type="email" placeholder="Your email...">
        <input onclick="newsletter();" type="submit" class="submit" value="">
      </div>
    </div>
  </div>
  <!-- .container end --> 
</div>
<a href="#" id="news_click" class="btn btn-success hide" data-toggle="modal" data-target="#yes_helpfuls">Yes</a>
<div class="modal fade" id="yes_helpfuls" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header" style="background:#5bc0de">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><i class=""> </i> </h4>
        </div>
        <div class="modal-body">
          <p><h5 id="news_text_change">Thank you for your feedback</h5></p>
        </div>
       
      </div>
    </div>
  </div>
<script type="text/javascript" src="http://asknuma.com/asknuma/public/quickadmin/dist/js/standalone/selectize.js"></script>
<script type="text/javascript" src="http://asknuma.com/asknuma/public/quickadmin/js/index.js"></script>

<script>
$('#dieases').selectize({
	maxItems: 1,
});
</script>
</body>
</html>