<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.12.3.js">
	</script>
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js">
</script>
<script src="https://code.jquery.com/ui/1.11.3/jquery-ui.min.js"></script>

<script src="//cdn.ckeditor.com/4.5.4/full/ckeditor.js"></script>
<script src="{{ URL::asset('public/quickadmin/js') }}/bootstrap.min.js"></script>
<script src="{{ URL::asset('public/quickadmin/js') }}/main.js"></script>
