</p>
<?php 
echo $user_detail['username'].'<br/>'; 
echo $user_detail['password']; ?>
</p>